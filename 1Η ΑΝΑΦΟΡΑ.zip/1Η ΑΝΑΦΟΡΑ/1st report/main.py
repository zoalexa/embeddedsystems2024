from machine import PWM, Pin
import time

# Define motor control pins (using PWM)
M1A = PWM(Pin(8))  # Motor 1 Forward
M1B = PWM(Pin(9))  # Motor 1 Backward
M2A = PWM(Pin(10)) # Motor 2 Forward
M2B = PWM(Pin(11)) # Motor 2 Backward

# Set PWM frequency for smooth operation
M1A.freq(1000)
M1B.freq(1000)
M2A.freq(1000)
M2B.freq(1000)

# Max RPM for both motors
MAX_RPM = 125

led = machine.Pin(0,Pin.OUT)
led.value(0)

def run_motors(rpm1, rpm2):
    """Run both motors at specific RPMs."""
    pwm1 = int((rpm1 / MAX_RPM) * 65535)  # Convert RPM to PWM
    pwm2 = int((rpm2 / MAX_RPM) * 65535)  # Convert RPM to PWM
    
    M1A.duty_u16(pwm1)
    M2A.duty_u16(pwm2)
    M1B.duty_u16(0)  # Ensure forward rotation
    M2B.duty_u16(0)  # Ensure forward rotation
    
    #print(f"Motor 1 -> RPM: {rpm1}, PWM: {pwm1}")
    #print(f"Motor 2 -> RPM: {rpm2}, PWM: {pwm2}")
    
def run_motors_backward(rpm1, rpm2):
    """Run both motors at specific RPMs."""
    pwm1 = int((rpm1 / MAX_RPM) * 65535)  # Convert RPM to PWM
    pwm2 = int((rpm2 / MAX_RPM) * 65535)  # Convert RPM to PWM
    
    M1A.duty_u16(0)
    M1B.duty_u16(pwm1)  # Ensure backward rotation
    
    M2A.duty_u16(0)
    M2B.duty_u16(pwm2)  # Ensure backward rotation
    
    print(f"Motor 1 -> RPM: {rpm1}, PWM: {pwm1}")
    print(f"Motor 2 -> RPM: {rpm2}, PWM: {pwm2}")

def stop_motors():
    """Stop both motors."""
    M1A.duty_u16(0)
    M1B.duty_u16(0)
    M2A.duty_u16(0)
    M2B.duty_u16(0)

# Test both motors at different speeds
speeds = [(50, 50), (75, 75), (125, 125), (50, 50), (25, 25)]

#while True:
run_motors(100,100)
time.sleep(10)
run_motors_backward(50,50)
time.sleep(10)
stop_motors()
led.value(1)